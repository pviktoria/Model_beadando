<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class Dolgozo extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            "Név"=>$this->Nev,
            "Város"=>$this->Varos,
            "Születés"=>$this->Szuletes,
            "Fizetés"=>$this->Fizetes,
            "created_at"=> $this->created_at->format("m/d/y"),
            "updated_at"=> $this->updated_at->format("m/d/y"),
        ];
    }
}
