<?php

namespace App\Http\Controllers;

use App\Models\Dolgozo;
use App\Http\Requests\StoreDolgozoRequest;
use App\Http\Requests\UpdateDolgozoRequest;
use \Illuminate\Support\Facades\DB;

class DolgozoController extends Controllers
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $dolgozo = Dolgozo::all();
        return view("dolgozo", ["Dolgozo"=>$dolgozo]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function addDolgozo() {
 
        return view( "add_dolgozo" );
    }
 
    public function storeDolgozo( Request $request ) {
        print_r( $request->all() );
 
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $dolgozo = new Dolgozo;
 
        $dolgozo->nev = $request->nev;
        $dolgozo->varos = $request->varos;
        $dolgozo->szuletes = $request->szuletes;
        $dolgozo->fizetes = $request->fizetes;
     
        $dolgozo->save();

        $request->session()->flash( "success", "Kiírás sikeres" );
        return redirect( "/uj-dolgozo" );
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Dolgozo  $dolgozo
     * @return \Illuminate\Http\Response
     */
    public function show(Dolgozo $dolgozo)
    {
        $dolgozo = Dolgozo::all();
 
        echo "<pre>";
        print_r( $dolgozo );
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Dolgozo  $dolgozo
     * @return \Illuminate\Http\Response
     */
    public function edit(Dolgozo $dolgozo)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateDolgozoRequest  $request
     * @param  \App\Models\Dolgozo  $dolgozo
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateDolgozoRequest $request, Dolgozo $dolgozo)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Dolgozo  $dolgozo
     * @return \Illuminate\Http\Response
     */
    public function destroyDolgozo( $id ) {
 
        $dolgozo = Dolgozo::find( $id );
        $dolgozo->delete();
     
        session()->flash( "success", "Dolgozó törölve" );
        return redirect( "/kiir-dolgozo" );
    }
}
