<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controller\DolgozoController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('dolgozo');
});

//Route::get("/home", [DolgozoController::class, "index"];);
Route::get( "/uj-dolgozo", [ DolgozoController::class, "addDolgozo" ]);
Route::post( "/tarol-dolgozo", [ DolgozoController::class, "storeDolgozo" ]);
Route::post( "/kiir-tanulodolgozoDolgoz", [ DolgozoController::class, "selectDolgozo" ]);
Route::get( "/delete/{id}", [ DolgozoDolgozo::class, "deleteDolgozo" ]);
Route::get( "/update/{id}", [ DolgozoController::class, "showUpdateDolgozo" ]);