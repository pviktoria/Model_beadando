<h1>Töltse ki a mezőket</h1>
 
@if( session()->has( "success "))
    <h3>{{ session( "success" ) }}</h3>
@endif

<form action="submit-dolgozo" method="post">
    @csfr
    <p>
        <label for=""> Név: </label>
        <input type="text" name="Név">
        <br>
    </p>
    <p>
        <label for=""> Varos: </label>
        <input type="text" name="Város">
        <br>
    </p>
    <p>
        <label for=""> Szuletes: </label>
        <input type="text" name="Születés">
    </p>
    <p>
        <label for=""> Fizetes: </label>
        <input type="text" name="Fizetés">
    </p>
    <p>
        <button type="submit">Küldés</button>
    </p>
</form>